const NFInput = document.getElementById('NF');
const massInput = document.getElementById('mass');
const AccelInput = document.getElementById('Accel');

const calculateFBtn = document.getElementById('calculateFBtn');
const clearFBtn = document.getElementById('clearFBtn');

const myuInput = document.getElementById('myu');
const FrmassInput = document.getElementById('Frmass');
const GravInput = document.getElementById('Grav');
const FFInput = document.getElementById('FF');

const calculateFrictionBtn = document.getElementById('calculateFrictionBtn');
const clearFrictionBtn = document.getElementById('clearFrictionBtn');


// Force
  
function calculateFValues() {
    let NF = parseFloat(NFInput.value);
    let mass = parseFloat(massInput.value);
    let Accel = parseFloat(AccelInput.value);

    if (isNaN(NF)) {
        NF = (mass * Accel);
        NFInput.value = NF.toFixed(2);
    }

    if (isNaN(mass)) {
        mass = (NF / Accel);
        massInput.value = mass.toFixed(2);
    }

    if (isNaN(Accel)) {
        Accel = (NF / mass);
        AccelInput.value = Accel.toFixed(2);
    }
}

function clearFValues() {
    NFInput.value = '';
    massInput.value = '';
    AccelInput.value = '';
    
}

calculateFBtn.addEventListener('click', calculateFValues);
clearFBtn.addEventListener('click', clearFValues);


// Friction

function calculateFrictionValues() {
    let myu = parseFloat(myuInput.value);
    let Frmass = parseFloat(FrmassInput.value);
    let Grav = parseFloat(GravInput.value);
  
    if (isNaN(myu) || isNaN(Frmass) || isNaN(Grav) || Grav === 0) {
      FFInput.value = '';
      return; // Exit the function if any input is not a number or Grav is 0
    }
  
    let FF = myu * Frmass * Grav;
    FFInput.value = FF.toFixed(2);
  }
  
  function clearFrictionValues() {
    FFInput.value = '';
    myuInput.value = '';
    FrmassInput.value = '';
    GravInput.value = '';
  }
  
calculateFrictionBtn.addEventListener('click', calculateFrictionValues);
clearFrictionBtn.addEventListener('click', clearFrictionValues);