const massEkInput = document.getElementById('massEk');
const velocityEkInput = document.getElementById('velocityEk');
const netEkInput = document.getElementById('netEk');
const calculateEkbtn = document.getElementById('calculateEkbtn');
const clearEkbtn = document.getElementById('clearEkbtn')

const massEgInput = document.getElementById('massEg');
const gravityEgInput = document.getElementById('gravityEg');
const heightEgInput = document.getElementById('heightEg');
const netEgInput = document.getElementById('netEg');
const calculateEgbtn = document.getElementById('calculateEgbtn');
const clearEgbtn = document.getElementById('clearEgbtn')

const springEeInput = document.getElementById('springEe');
const deformationEeInput = document.getElementById('deformationEe');
const netEeInput = document.getElementById('netEe');
const calculateEebtn = document.getElementById('calculateEebtn');
const clearEebtn = document.getElementById('clearEebtn')



//Kinetic Energy

function calculateEkValues() {
    let massEk = parseFloat(massEkInput.value);
    let velocityEk = parseFloat(velocityEkInput.value);
    let netEk = parseFloat(netEkInput.value)
  
    if (isNaN(massEk)) {
        massEk = (2*netEk)/(velocityEk*velocityEk);
        massEkInput.value = massEk.toFixed(2);
    }

    if (isNaN(velocityEk)) {
        velocityEk = Math.sqrt((2 * netEk)/(massEk));
        velocityEkInput.value = velocityEk.toFixed(2);
    }

    if (isNaN(netEk)) {
        netEk = (.5)*(massEk)*(velocityEk)**2;
        netEkInput.value = netEk.toFixed(2);
    }
}

function clearEkValues() {
    massEkInput.value = '';
    velocityEkInput.value = '';
    netEkInput.value = '';    
}

calculateEkbtn.addEventListener('click', calculateEkValues);
clearEkbtn.addEventListener('click', clearEkValues);

//Gravitational Energy

function calculateEgValues() {
    let massEg = parseFloat(massEgInput.value);
    let gravityEg = parseFloat(gravityEgInput.value);
    let heightEg = parseFloat(heightEgInput.value);
    let netEg = parseFloat(netEgInput.value);
  
    if (isNaN(massEg)) {
        massEg = (netEg)/(gravityEg*heightEg);
        massEgInput.value = massEg.toFixed(2);
    }

    if (isNaN(gravityEg)) {
        gravityEg = (netEg)/(massEg*heightEg);
        gravityEgInput.value = gravityEg.toFixed(2);
    }

    if (isNaN(heightEg)) {
        heightEg = (netEg)/(massEg*gravityEg);
        heightEgInput.value = heightEg.toFixed(2);
    }

    if (isNaN(netEg)) {
        netEg = (heightEg)*(massEg)*(gravityEg);
        netEgInput.value = netEg.toFixed(2);
    }
}

function clearEgValues() {
    massEgInput.value = '';
    gravityEgInput.value = '';
    heightEgInput.value = '';
    netEgInput.value = '';    
}

calculateEgbtn.addEventListener('click', calculateEgValues);
clearEgbtn.addEventListener('click', clearEgValues);


//Elastic Energy

function calculateEeValues() {
    let springEe = parseFloat(springEeInput.value);
    let deformationEe = parseFloat(deformationEeInput.value);
    let netEe = parseFloat(netEeInput.value);
  
    if (isNaN(springEe)) {
        springEe = (2*netEe)/(deformationEe**2);
        springEeInput.value = springEe.toFixed(2);
    }

    if (isNaN(deformationEe)) {
        deformationEe = Math.sqrt((2*netEe)/springEe);
        deformationEeInput.value = deformationEe.toFixed(2);
    }

    if (isNaN(netEe)) {
        netEe = (0.5)*(springEe)*(deformationEe)**2;
        netEeInput.value = netEe.toFixed(2);
    }
}

function clearEeValues() {
    springEeInput.value = '';
    deformationEeInput.value = '';
    netEeInput.value = '';    
}

calculateEebtn.addEventListener('click', calculateEeValues);
clearEebtn.addEventListener('click', clearEeValues);
