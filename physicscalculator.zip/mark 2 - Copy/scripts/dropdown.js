const dropdownToggle = document.getElementById('dropdownToggle');

function toggleDrop() {
    document.getElementById("myDropdown").classList.toggle("show");
  }

dropdownToggle.addEventListener('click', toggleDrop)