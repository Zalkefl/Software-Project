const distanceInput = document.getElementById('distance');
const initialVelocityInput = document.getElementById('initial-velocity');
const finalVelocityInput = document.getElementById('final-velocity');
const accelerationInput = document.getElementById('acceleration');
const timeInput = document.getElementById('time');
const calculateKinBtn = document.getElementById('calculateKinBtn');
const clearKinBtn = document.getElementById('clearKinBtn');


  
function calculateKinValues() {
    let distance = parseFloat(distanceInput.value);
    let initialVelocity = parseFloat(initialVelocityInput.value);
    let finalVelocity = parseFloat(finalVelocityInput.value);
    let acceleration = parseFloat(accelerationInput.value);
    let time = parseFloat(timeInput.value);

    if (isNaN(distance)) {
        distance = (initialVelocity + finalVelocity) * time / 2;
        distanceInput.value = distance.toFixed(2);
    }

    if (isNaN(initialVelocity)) {
        initialVelocity = (2 * distance / time) - finalVelocity;
        initialVelocityInput.value = initialVelocity.toFixed(2);
    }

    if (isNaN(finalVelocity)) {
        finalVelocity = (2 * distance / time) - initialVelocity;
        finalVelocityInput.value = finalVelocity.toFixed(2);
    }

    if (isNaN(acceleration)) {
        acceleration = (2 * (distance - (initialVelocity * time))) / (time * time);
        accelerationInput.value = acceleration.toFixed(2);
    }

    if (isNaN(time)) {
        time = (2 * distance) / (initialVelocity + finalVelocity);
        timeInput.value = time.toFixed(2);
    }
}

function clearKinValues() {
    distanceInput.value = '';
    initialVelocityInput.value = '';
    finalVelocityInput.value = '';
    accelerationInput.value = '';
    timeInput.value = '';
    
}

calculateKinBtn.addEventListener('click', calculateKinValues);
clearKinBtn.addEventListener('click', clearKinValues)
