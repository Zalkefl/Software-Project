Physics Calculator
This is a simple web application that allows users to perform various physics calculations. The application consists of two pages: a startup page and a page for choosing a physics topic. Users can click on the "Start" button on the startup page to go to the topic selection page, where they can choose a topic to perform calculations in. Currently, the application supports three topics: kinematics, forces, and energy.

Installation
To use this application, you need to have Microsoft Visual Studio Code running on your computer. You can install it from this link for your respective device: https://code.visualstudio.com/. In order to install the files for the website, go through the github file named "Website Code", install the zip and import the file into VS Code.

Usage
Once you have the application downloaded, you can just click the run button on the top and in the dropdown, click "Run". This will then open up a prompt to ask which browser to open it up on, where the user should click whichever respective browser they use. Note: Make sure to be on the "index.html" file so you can start from the beginning of the website.

From the startup page, click on the "Start" button to go to the topic selection page. From there, you can choose a topic to perform calculations in. The projected outcome of this program is to be taken to a page through the select topic page where you can enter values for the relevant physics variables and perform calculations. 

Credits
This application was created by Aarib and Zalkefl as a project for ICS4U.